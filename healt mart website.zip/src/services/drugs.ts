import { supabase } from '../lib/supabase'
import type { DatabaseDrug, DatabaseHospital } from '../lib/supabase'

export interface DrugWithHospital extends DatabaseDrug {
  hospital: DatabaseHospital
}

export class DrugService {
  static async getAllDrugs(): Promise<DrugWithHospital[]> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .select(`
        *,
        hospital:app_057a700728_hospitals(*)
      `)
      .eq('active', true)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async getDrugsByCategory(category: string): Promise<DrugWithHospital[]> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .select(`
        *,
        hospital:app_057a700728_hospitals(*)
      `)
      .eq('category', category)
      .eq('active', true)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async searchDrugs(searchTerm: string): Promise<DrugWithHospital[]> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .select(`
        *,
        hospital:app_057a700728_hospitals(*)
      `)
      .ilike('name', `%${searchTerm}%`)
      .eq('active', true)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async getDrugById(id: string): Promise<DrugWithHospital | null> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .select(`
        *,
        hospital:app_057a700728_hospitals(*)
      `)
      .eq('id', id)
      .eq('active', true)
      .single()

    if (error) throw error
    return data
  }

  static async getHospitalDrugs(hospitalId: string): Promise<DatabaseDrug[]> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .select('*')
      .eq('hospital_id', hospitalId)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async createDrug(drugData: Omit<DatabaseDrug, 'id' | 'created_at' | 'updated_at'>): Promise<DatabaseDrug> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .insert(drugData)
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async updateDrug(id: string, updates: Partial<DatabaseDrug>): Promise<DatabaseDrug> {
    const { data, error } = await supabase
      .from('app_057a700728_drugs')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async deleteDrug(id: string): Promise<void> {
    const { error } = await supabase
      .from('app_057a700728_drugs')
      .update({ active: false, updated_at: new Date().toISOString() })
      .eq('id', id)

    if (error) throw error
  }
}