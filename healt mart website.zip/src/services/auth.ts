import { supabase } from '../lib/supabase'
import type { User } from '@supabase/supabase-js'

export interface SignUpData {
  email: string
  password: string
  fullName: string
  phone?: string
  address?: string
  role: 'patient' | 'hospital'
  hospitalName?: string
  hospitalAddress?: string
  hospitalPhone?: string
  licenseNumber?: string
}

export interface SignInData {
  email: string
  password: string
}

export class AuthService {
  static async signUp(data: SignUpData) {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            full_name: data.fullName,
            role: data.role,
          }
        }
      })

      if (authError) throw authError

      if (authData.user) {
        // Create profile based on role
        if (data.role === 'patient') {
          const { error: profileError } = await supabase
            .from('app_057a700728_patients')
            .insert({
              user_id: authData.user.id,
              full_name: data.fullName,
              phone: data.phone || null,
              address: data.address || null,
            })

          if (profileError) throw profileError
        } else if (data.role === 'hospital') {
          const { error: hospitalError } = await supabase
            .from('app_057a700728_hospitals')
            .insert({
              user_id: authData.user.id,
              name: data.hospitalName || '',
              address: data.hospitalAddress || '',
              phone: data.hospitalPhone || '',
              email: data.email,
              license_number: data.licenseNumber || '',
              status: 'pending',
            })

          if (hospitalError) throw hospitalError
        }
      }

      return { user: authData.user, session: authData.session }
    } catch (error) {
      throw error
    }
  }

  static async signIn(data: SignInData) {
    const { data: authData, error } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    })

    if (error) throw error
    return { user: authData.user, session: authData.session }
  }

  static async signOut() {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
  }

  static async getCurrentUser() {
    const { data: { user } } = await supabase.auth.getUser()
    return user
  }

  static async getSession() {
    const { data: { session } } = await supabase.auth.getSession()
    return session
  }

  static onAuthStateChange(callback: (user: User | null) => void) {
    return supabase.auth.onAuthStateChange((_event, session) => {
      callback(session?.user ?? null)
    })
  }
}