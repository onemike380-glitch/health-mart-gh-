import { supabase } from '../lib/supabase'
import { AuthService } from './auth'
import { CartService } from './cart'
import type { DatabaseOrder, DatabaseOrderItem } from '../lib/supabase'

export interface OrderWithItems extends DatabaseOrder {
  order_items: Array<DatabaseOrderItem & {
    drug: {
      name: string
      image_url: string | null
    }
  }>
  hospital: {
    name: string
    address: string
    phone: string
  }
}

export interface CreateOrderData {
  hospitalId: string
  deliveryAddress: string
  notes?: string
  cartItems: Array<{
    drugId: string
    quantity: number
    price: number
  }>
}

export class OrderService {
  static async createOrder(orderData: CreateOrderData): Promise<DatabaseOrder> {
    const user = await AuthService.getCurrentUser()
    if (!user) throw new Error('User not authenticated')

    // Get patient ID
    const { data: patient, error: patientError } = await supabase
      .from('app_057a700728_patients')
      .select('id')
      .eq('user_id', user.id)
      .single()

    if (patientError) throw patientError

    // Calculate total amount
    const totalAmount = orderData.cartItems.reduce(
      (sum, item) => sum + (item.price * item.quantity), 
      0
    )

    // Create order
    const { data: order, error: orderError } = await supabase
      .from('app_057a700728_orders')
      .insert({
        patient_id: patient.id,
        hospital_id: orderData.hospitalId,
        total_amount: totalAmount,
        delivery_address: orderData.deliveryAddress,
        notes: orderData.notes || null,
        status: 'pending'
      })
      .select()
      .single()

    if (orderError) throw orderError

    // Create order items
    const orderItems = orderData.cartItems.map(item => ({
      order_id: order.id,
      drug_id: item.drugId,
      quantity: item.quantity,
      price: item.price
    }))

    const { error: itemsError } = await supabase
      .from('app_057a700728_order_items')
      .insert(orderItems)

    if (itemsError) throw itemsError

    // Clear cart after successful order
    await CartService.clearCart()

    return order
  }

  static async getPatientOrders(): Promise<OrderWithItems[]> {
    const user = await AuthService.getCurrentUser()
    if (!user) throw new Error('User not authenticated')

    // Get patient ID
    const { data: patient, error: patientError } = await supabase
      .from('app_057a700728_patients')
      .select('id')
      .eq('user_id', user.id)
      .single()

    if (patientError) throw patientError

    const { data, error } = await supabase
      .from('app_057a700728_orders')
      .select(`
        *,
        order_items:app_057a700728_order_items(
          *,
          drug:app_057a700728_drugs(
            name,
            image_url
          )
        ),
        hospital:app_057a700728_hospitals(
          name,
          address,
          phone
        )
      `)
      .eq('patient_id', patient.id)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async getHospitalOrders(): Promise<OrderWithItems[]> {
    const user = await AuthService.getCurrentUser()
    if (!user) throw new Error('User not authenticated')

    // Get hospital ID
    const { data: hospital, error: hospitalError } = await supabase
      .from('app_057a700728_hospitals')
      .select('id')
      .eq('user_id', user.id)
      .single()

    if (hospitalError) throw hospitalError

    const { data, error } = await supabase
      .from('app_057a700728_orders')
      .select(`
        *,
        order_items:app_057a700728_order_items(
          *,
          drug:app_057a700728_drugs(
            name,
            image_url
          )
        ),
        hospital:app_057a700728_hospitals(
          name,
          address,
          phone
        )
      `)
      .eq('hospital_id', hospital.id)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async updateOrderStatus(orderId: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('app_057a700728_orders')
      .update({ 
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', orderId)

    if (error) throw error
  }

  static async getOrderById(orderId: string): Promise<OrderWithItems | null> {
    const { data, error } = await supabase
      .from('app_057a700728_orders')
      .select(`
        *,
        order_items:app_057a700728_order_items(
          *,
          drug:app_057a700728_drugs(
            name,
            image_url
          )
        ),
        hospital:app_057a700728_hospitals(
          name,
          address,
          phone
        )
      `)
      .eq('id', orderId)
      .single()

    if (error) throw error
    return data
  }
}