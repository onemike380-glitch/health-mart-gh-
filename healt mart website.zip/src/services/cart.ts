import { supabase } from '../lib/supabase'
import { AuthService } from './auth'
import type { DatabaseCartItem } from '../lib/supabase'

export interface CartItemWithDrug extends DatabaseCartItem {
  drug: {
    id: string
    name: string
    price: number
    image_url: string | null
    hospital_id: string
    stock_quantity: number
  }
}

export class CartService {
  static async getCartItems(): Promise<CartItemWithDrug[]> {
    const user = await AuthService.getCurrentUser()
    if (!user) throw new Error('User not authenticated')

    // Get patient ID
    const { data: patient, error: patientError } = await supabase
      .from('app_057a700728_patients')
      .select('id')
      .eq('user_id', user.id)
      .single()

    if (patientError) throw patientError

    const { data, error } = await supabase
      .from('app_057a700728_cart_items')
      .select(`
        *,
        drug:app_057a700728_drugs(
          id,
          name,
          price,
          image_url,
          hospital_id,
          stock_quantity
        )
      `)
      .eq('patient_id', patient.id)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async addToCart(drugId: string, quantity: number): Promise<void> {
    const user = await AuthService.getCurrentUser()
    if (!user) throw new Error('User not authenticated')

    // Get patient ID
    const { data: patient, error: patientError } = await supabase
      .from('app_057a700728_patients')
      .select('id')
      .eq('user_id', user.id)
      .single()

    if (patientError) throw patientError

    // Check if item already exists in cart
    const { data: existingItem, error: checkError } = await supabase
      .from('app_057a700728_cart_items')
      .select('*')
      .eq('patient_id', patient.id)
      .eq('drug_id', drugId)
      .single()

    if (checkError && checkError.code !== 'PGRST116') throw checkError

    if (existingItem) {
      // Update quantity
      const { error: updateError } = await supabase
        .from('app_057a700728_cart_items')
        .update({ 
          quantity: existingItem.quantity + quantity,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingItem.id)

      if (updateError) throw updateError
    } else {
      // Insert new item
      const { error: insertError } = await supabase
        .from('app_057a700728_cart_items')
        .insert({
          patient_id: patient.id,
          drug_id: drugId,
          quantity
        })

      if (insertError) throw insertError
    }
  }

  static async updateCartItem(itemId: string, quantity: number): Promise<void> {
    const { error } = await supabase
      .from('app_057a700728_cart_items')
      .update({ 
        quantity,
        updated_at: new Date().toISOString()
      })
      .eq('id', itemId)

    if (error) throw error
  }

  static async removeFromCart(itemId: string): Promise<void> {
    const { error } = await supabase
      .from('app_057a700728_cart_items')
      .delete()
      .eq('id', itemId)

    if (error) throw error
  }

  static async clearCart(): Promise<void> {
    const user = await AuthService.getCurrentUser()
    if (!user) throw new Error('User not authenticated')

    // Get patient ID
    const { data: patient, error: patientError } = await supabase
      .from('app_057a700728_patients')
      .select('id')
      .eq('user_id', user.id)
      .single()

    if (patientError) throw patientError

    const { error } = await supabase
      .from('app_057a700728_cart_items')
      .delete()
      .eq('patient_id', patient.id)

    if (error) throw error
  }
}