import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://yufjgguybvguzdwjwekx.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl1ZmpnZ3V5YnZndXpkd2p3ZWt4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU3OTM5NTYsImV4cCI6MjA3MTM2OTk1Nn0.HtbgbbygOquZk-KFv7VDok5DjpMtPBMG-XXSP5OqewM'

export const supabase = createClient(supabaseUrl, supabaseKey)

// Database types based on our schema
export interface DatabaseHospital {
  id: string
  user_id: string
  name: string
  address: string
  phone: string
  email: string
  license_number: string
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
  updated_at: string
}

export interface DatabaseDrug {
  id: string
  hospital_id: string
  name: string
  description: string | null
  category: string
  price: number
  stock_quantity: number
  image_url: string | null
  requires_prescription: boolean
  active: boolean
  created_at: string
  updated_at: string
}

export interface DatabasePatient {
  id: string
  user_id: string
  full_name: string
  phone: string | null
  address: string | null
  date_of_birth: string | null
  created_at: string
  updated_at: string
}

export interface DatabaseOrder {
  id: string
  patient_id: string
  hospital_id: string
  total_amount: number
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
  delivery_address: string
  notes: string | null
  created_at: string
  updated_at: string
}

export interface DatabaseOrderItem {
  id: string
  order_id: string
  drug_id: string
  quantity: number
  price: number
  created_at: string
}

export interface DatabaseCartItem {
  id: string
  patient_id: string
  drug_id: string
  quantity: number
  created_at: string
  updated_at: string
}