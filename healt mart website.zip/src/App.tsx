import React, { useState } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { Header } from './components/Header';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DrugsPage } from './pages/DrugsPage';
import { CartPage } from './pages/CartPage';

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'login':
        return <LoginPage onNavigate={handleNavigate} />;
      case 'register':
        return <RegisterPage onNavigate={handleNavigate} />;
      case 'drugs':
        return <DrugsPage onNavigate={handleNavigate} />;
      case 'cart':
        return <CartPage onNavigate={handleNavigate} />;
      case 'hospitals':
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Hospitals</h1>
              <p className="text-gray-600">Coming soon...</p>
            </div>
          </div>
        );
      case 'dashboard':
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Hospital Dashboard</h1>
              <p className="text-gray-600">Coming soon...</p>
            </div>
          </div>
        );
      case 'admin':
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Admin Panel</h1>
              <p className="text-gray-600">Coming soon...</p>
            </div>
          </div>
        );
      case 'profile':
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Profile</h1>
              <p className="text-gray-600">Coming soon...</p>
            </div>
          </div>
        );
      case 'orders':
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">My Orders</h1>
              <p className="text-gray-600">Coming soon...</p>
            </div>
          </div>
        );
      case 'checkout':
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Checkout</h1>
              <p className="text-gray-600">Coming soon...</p>
            </div>
          </div>
        );
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <AuthProvider>
      <CartProvider>
        <TooltipProvider>
          <Toaster />
          <div className="min-h-screen bg-gray-50">
            <Header onNavigate={handleNavigate} currentPage={currentPage} />
            <main>
              {renderPage()}
            </main>
          </div>
        </TooltipProvider>
      </CartProvider>
    </AuthProvider>
  );
};

export default App;