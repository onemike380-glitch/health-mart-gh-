export interface User {
  id: string;
  email: string;
  name: string;
  role: 'patient' | 'hospital' | 'admin';
  phone?: string;
  address?: string;
  hospitalId?: string;
  createdAt: Date;
}

export interface Drug {
  id: string;
  name: string;
  description: string;
  category: string;
  manufacturer: string;
  price: number;
  stock: number;
  imageUrl: string;
  prescriptionRequired: boolean;
  hospitalId: string;
  hospitalName: string;
  expiryDate: Date;
  dosage: string;
  sideEffects?: string;
  createdAt: Date;
}

export interface CartItem {
  drugId: string;
  drug: Drug;
  quantity: number;
}

export interface Order {
  id: string;
  patientId: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
  paymentStatus: 'pending' | 'paid' | 'failed' | 'refunded';
  deliveryAddress: string;
  prescriptionUrl?: string;
  hospitalId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface OrderItem {
  drugId: string;
  drugName: string;
  quantity: number;
  price: number;
  subtotal: number;
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  licenseNumber: string;
  isVerified: boolean;
  description?: string;
  createdAt: Date;
}

export interface Prescription {
  id: string;
  patientId: string;
  doctorName: string;
  hospitalId: string;
  drugs: string[];
  imageUrl: string;
  isUsed: boolean;
  createdAt: Date;
}