import { Drug, Hospital, Order } from '../types';

export const mockDrugs: Drug[] = [
  {
    id: '1',
    name: 'Paracetamol',
    description: 'Pain relief and fever reducer',
    category: 'Pain Relief',
    manufacturer: 'PharmaCorp',
    price: 15.50,
    stock: 100,
    imageUrl: '/api/placeholder/300/200',
    prescriptionRequired: false,
    hospitalId: 'hosp1',
    hospitalName: 'Ridge Hospital',
    expiryDate: new Date('2025-12-31'),
    dosage: '500mg tablets',
    sideEffects: 'Rare: skin rash, nausea',
    createdAt: new Date()
  },
  {
    id: '2',
    name: 'Amoxicillin',
    description: 'Antibiotic for bacterial infections',
    category: 'Antibiotics',
    manufacturer: 'MediCare Ltd',
    price: 45.00,
    stock: 50,
    imageUrl: '/api/placeholder/300/200',
    prescriptionRequired: true,
    hospitalId: 'hosp1',
    hospitalName: 'Ridge Hospital',
    expiryDate: new Date('2026-06-30'),
    dosage: '250mg capsules',
    sideEffects: 'Common: nausea, diarrhea. Rare: allergic reactions',
    createdAt: new Date()
  },
  {
    id: '3',
    name: 'Insulin Glargine',
    description: 'Long-acting insulin for diabetes',
    category: 'Diabetes',
    manufacturer: 'DiabetCare Inc',
    price: 180.00,
    stock: 25,
    imageUrl: '/api/placeholder/300/200',
    prescriptionRequired: true,
    hospitalId: 'hosp2',
    hospitalName: 'Korle Bu Teaching Hospital',
    expiryDate: new Date('2025-09-15'),
    dosage: '100 units/mL injection',
    sideEffects: 'Common: injection site reactions, hypoglycemia',
    createdAt: new Date()
  },
  {
    id: '4',
    name: 'Omeprazole',
    description: 'Proton pump inhibitor for acid reflux',
    category: 'Gastric',
    manufacturer: 'GastroMed',
    price: 32.75,
    stock: 75,
    imageUrl: '/api/placeholder/300/200',
    prescriptionRequired: false,
    hospitalId: 'hosp2',
    hospitalName: 'Korle Bu Teaching Hospital',
    expiryDate: new Date('2026-03-20'),
    dosage: '20mg capsules',
    sideEffects: 'Rare: headache, stomach pain',
    createdAt: new Date()
  },
  {
    id: '5',
    name: 'Lisinopril',
    description: 'ACE inhibitor for high blood pressure',
    category: 'Cardiovascular',
    manufacturer: 'HeartCare Pharma',
    price: 28.50,
    stock: 60,
    imageUrl: '/api/placeholder/300/200',
    prescriptionRequired: true,
    hospitalId: 'hosp3',
    hospitalName: '37 Military Hospital',
    expiryDate: new Date('2025-11-10'),
    dosage: '10mg tablets',
    sideEffects: 'Common: dry cough, dizziness',
    createdAt: new Date()
  },
  {
    id: '6',
    name: 'Aspirin',
    description: 'Anti-inflammatory and blood thinner',
    category: 'Pain Relief',
    manufacturer: 'CardioMed',
    price: 12.25,
    stock: 150,
    imageUrl: '/api/placeholder/300/200',
    prescriptionRequired: false,
    hospitalId: 'hosp3',
    hospitalName: '37 Military Hospital',
    expiryDate: new Date('2026-08-05'),
    dosage: '75mg tablets',
    sideEffects: 'Common: stomach upset. Rare: bleeding',
    createdAt: new Date()
  }
];

export const mockHospitals: Hospital[] = [
  {
    id: 'hosp1',
    name: 'Ridge Hospital',
    address: 'Ridge, Accra, Ghana',
    phone: '+233 302 776 401',
    email: 'info@ridgehospital.com.gh',
    licenseNumber: 'GHS-RH-001',
    isVerified: true,
    description: 'Premier healthcare facility in Accra',
    createdAt: new Date()
  },
  {
    id: 'hosp2',
    name: 'Korle Bu Teaching Hospital',
    address: 'Korle Bu, Accra, Ghana',
    phone: '+233 302 674 281',
    email: 'admin@kbth.gov.gh',
    licenseNumber: 'GHS-KBTH-002',
    isVerified: true,
    description: 'Leading teaching hospital in West Africa',
    createdAt: new Date()
  },
  {
    id: 'hosp3',
    name: '37 Military Hospital',
    address: '37 Military Hospital Road, Accra',
    phone: '+233 302 776 111',
    email: 'info@37militaryhospital.mil.gh',
    licenseNumber: 'GAF-37MH-003',
    isVerified: true,
    description: 'Military hospital serving the public',
    createdAt: new Date()
  }
];

export const mockOrders: Order[] = [
  {
    id: 'order1',
    patientId: 'patient1',
    items: [
      {
        drugId: '1',
        drugName: 'Paracetamol',
        quantity: 2,
        price: 15.50,
        subtotal: 31.00
      }
    ],
    totalAmount: 31.00,
    status: 'delivered',
    paymentStatus: 'paid',
    deliveryAddress: 'East Legon, Accra',
    hospitalId: 'hosp1',
    createdAt: new Date('2025-01-15'),
    updatedAt: new Date('2025-01-16')
  }
];