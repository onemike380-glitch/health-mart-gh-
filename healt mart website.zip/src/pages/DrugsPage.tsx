import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { DrugService, DrugWithHospital } from '../services/drugs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Search, ShoppingCart, MapPin, Phone, Mail, Plus, Minus, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface DrugsPageProps {
  onNavigate: (page: string) => void;
}

export const DrugsPage: React.FC<DrugsPageProps> = ({ onNavigate }) => {
  const [drugs, setDrugs] = useState<DrugWithHospital[]>([]);
  const [filteredDrugs, setFilteredDrugs] = useState<DrugWithHospital[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  
  const { user } = useAuth();
  const { addToCart, totalItems } = useCart();

  const categories = ['all', 'pain relief', 'antibiotics', 'vitamins', 'diabetes', 'heart', 'respiratory'];

  useEffect(() => {
    loadDrugs();
  }, []);

  useEffect(() => {
    filterDrugs();
  }, [drugs, searchTerm, selectedCategory]);

  const loadDrugs = async () => {
    try {
      setLoading(true);
      const drugsData = await DrugService.getAllDrugs();
      setDrugs(drugsData);
      
      // Initialize quantities
      const initialQuantities: Record<string, number> = {};
      drugsData.forEach(drug => {
        initialQuantities[drug.id] = 1;
      });
      setQuantities(initialQuantities);
    } catch (error) {
      console.error('Failed to load drugs:', error);
      toast.error('Failed to load medications');
    } finally {
      setLoading(false);
    }
  };

  const filterDrugs = () => {
    let filtered = drugs;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(drug => 
        drug.category.toLowerCase().includes(selectedCategory.toLowerCase())
      );
    }

    if (searchTerm) {
      filtered = filtered.filter(drug =>
        drug.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        drug.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        drug.hospital.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredDrugs(filtered);
  };

  const handleQuantityChange = (drugId: string, change: number) => {
    setQuantities(prev => ({
      ...prev,
      [drugId]: Math.max(1, (prev[drugId] || 1) + change)
    }));
  };

  const handleAddToCart = async (drug: DrugWithHospital) => {
    if (!user) {
      toast.error('Please login to add items to cart');
      onNavigate('login');
      return;
    }

    const quantity = quantities[drug.id] || 1;
    
    if (quantity > drug.stock_quantity) {
      toast.error(`Only ${drug.stock_quantity} items available in stock`);
      return;
    }

    try {
      await addToCart(drug.id, quantity);
      toast.success(`${drug.name} added to cart!`);
    } catch (error) {
      toast.error('Failed to add item to cart');
    }
  };

  const formatPrice = (price: number) => {
    return `GH₵ ${price.toFixed(2)}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-green-600" />
          <p>Loading medications...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <button
                onClick={() => onNavigate('home')}
                className="text-2xl font-bold text-green-600 hover:text-green-700"
              >
                Health Mart GH
              </button>
            </div>
            
            <div className="flex items-center space-x-4">
              {user && (
                <button
                  onClick={() => onNavigate('cart')}
                  className="relative p-2 text-gray-600 hover:text-green-600"
                >
                  <ShoppingCart className="h-6 w-6" />
                  {totalItems > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs">
                      {totalItems}
                    </Badge>
                  )}
                </button>
              )}
              
              {user ? (
                <div className="text-sm text-gray-600">
                  Welcome, {user.user_metadata?.full_name || user.email}
                </div>
              ) : (
                <Button onClick={() => onNavigate('login')} variant="outline">
                  Login
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Browse Medications</h1>
          
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Search medications, hospitals..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category.charAt(0).toUpperCase() + category.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Drugs Grid */}
        {filteredDrugs.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No medications found matching your criteria.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDrugs.map((drug) => (
              <Card key={drug.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-w-16 aspect-h-9">
                  {drug.image_url ? (
                    <img
                      src={drug.image_url}
                      alt={drug.name}
                      className="w-full h-48 object-cover"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                      <span className="text-gray-400">No image available</span>
                    </div>
                  )}
                </div>
                
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{drug.name}</CardTitle>
                      <CardDescription className="text-sm text-gray-600">
                        {drug.description}
                      </CardDescription>
                    </div>
                    <Badge variant={drug.requires_prescription ? "destructive" : "secondary"}>
                      {drug.requires_prescription ? "Prescription" : "OTC"}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-green-600">
                        {formatPrice(drug.price)}
                      </span>
                      <span className="text-sm text-gray-500">
                        Stock: {drug.stock_quantity}
                      </span>
                    </div>
                    
                    <div className="text-sm text-gray-600">
                      <div className="flex items-center gap-1 mb-1">
                        <MapPin className="h-3 w-3" />
                        <span className="font-medium">{drug.hospital.name}</span>
                      </div>
                      <div className="flex items-center gap-1 mb-1">
                        <MapPin className="h-3 w-3" />
                        <span>{drug.hospital.address}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        <span>{drug.hospital.phone}</span>
                      </div>
                    </div>
                    
                    <Badge>{drug.category}</Badge>
                    
                    {drug.stock_quantity > 0 ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Quantity:</span>
                          <div className="flex items-center space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleQuantityChange(drug.id, -1)}
                              disabled={quantities[drug.id] <= 1}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center">{quantities[drug.id] || 1}</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleQuantityChange(drug.id, 1)}
                              disabled={quantities[drug.id] >= drug.stock_quantity}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        
                        <Button
                          onClick={() => handleAddToCart(drug)}
                          className="w-full"
                          disabled={!user}
                        >
                          <ShoppingCart className="mr-2 h-4 w-4" />
                          Add to Cart
                        </Button>
                      </div>
                    ) : (
                      <Button disabled className="w-full">
                        Out of Stock
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};