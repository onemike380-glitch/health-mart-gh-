import React from 'react';
import { Drug } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ShoppingCart, AlertCircle, Building2 } from 'lucide-react';
import { toast } from 'sonner';

interface DrugCardProps {
  drug: Drug;
  onViewDetails: (drug: Drug) => void;
}

export const DrugCard: React.FC<DrugCardProps> = ({ drug, onViewDetails }) => {
  const { user } = useAuth();
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    if (!user) {
      toast.error('Please login to add items to cart');
      return;
    }
    if (user.role !== 'patient') {
      toast.error('Only patients can purchase medications');
      return;
    }
    addToCart(drug, 1);
    toast.success(`${drug.name} added to cart`);
  };

  const formatPrice = (price: number) => {
    return `GH₵ ${price.toFixed(2)}`;
  };

  const isExpiringSoon = () => {
    const today = new Date();
    const expiryDate = new Date(drug.expiryDate);
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 90; // Expiring within 3 months
  };

  return (
    <Card className="h-full flex flex-col hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="aspect-video bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
          <img 
            src={drug.imageUrl} 
            alt={drug.name}
            className="w-full h-full object-cover rounded-lg"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23f3f4f6'/%3E%3Ctext x='150' y='100' font-family='Arial' font-size='14' fill='%236b7280' text-anchor='middle' dy='0.3em'%3E%F0%9F%92%8A Medicine%3C/text%3E%3C/svg%3E";
            }}
          />
        </div>
        
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-semibold line-clamp-2">{drug.name}</CardTitle>
          <div className="flex flex-col items-end gap-1">
            {drug.prescriptionRequired && (
              <Badge variant="secondary" className="text-xs">
                Prescription Required
              </Badge>
            )}
            {isExpiringSoon() && (
              <Badge variant="destructive" className="text-xs">
                <AlertCircle className="h-3 w-3 mr-1" />
                Expiring Soon
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-grow">
        <div className="space-y-2">
          <p className="text-sm text-gray-600 line-clamp-2">{drug.description}</p>
          
          <div className="flex items-center text-sm text-gray-500">
            <Building2 className="h-4 w-4 mr-1" />
            {drug.hospitalName}
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">Category:</span>
            <Badge variant="outline">{drug.category}</Badge>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">Dosage:</span>
            <span className="text-sm">{drug.dosage}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">Stock:</span>
            <span className={`text-sm font-medium ${drug.stock <= 10 ? 'text-red-600' : 'text-green-600'}`}>
              {drug.stock} units
            </span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="pt-4 border-t">
        <div className="w-full space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-2xl font-bold text-green-600">{formatPrice(drug.price)}</span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onViewDetails(drug)}
            >
              View Details
            </Button>
          </div>
          
          {user?.role === 'patient' && (
            <Button 
              className="w-full" 
              onClick={handleAddToCart}
              disabled={drug.stock === 0}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              {drug.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
};